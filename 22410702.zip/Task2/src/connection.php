<?php


$db_host="db"; //localhost server 
$db_user="root"; //database username
$db_password="csym019"; //database password   
$db_name="Recipe"; //database name

try
{
 $db=new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_password);
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOEXCEPTION $e)
{
 $e->getMessage();
}
?>
